-- schema.sql
-- 未腚博客的数据表结构。首次部署前需要用 wrangler d1 execute 把这个文件灌进 D1 数据库。

CREATE TABLE IF NOT EXISTS posts (
  id         TEXT PRIMARY KEY,
  author     TEXT NOT NULL,
  title      TEXT NOT NULL,
  content    TEXT NOT NULL,
  likes      INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts (created_at DESC);

-- 用于简单的按 IP 限流（发布间隔 15 秒）
CREATE TABLE IF NOT EXISTS rate_limits (
  ip        TEXT PRIMARY KEY,
  last_post INTEGER NOT NULL
);
