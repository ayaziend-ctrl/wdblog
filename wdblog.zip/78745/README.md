# 未腚博客 · 部署说明（Cloudflare Workers + D1 版）

一个公开、免注册的留言墙：任何人都能发布内容，所有人都能立刻看到。这一版数据存储用的是 **Cloudflare D1**（真正的 SQL 数据库），不再是 KV。

## 文件结构

```
weiding-blog/
├── wrangler.toml         ← Worker 配置：静态资源目录 + D1 绑定
├── schema.sql              ← 数据表结构，首次部署前需要灌进 D1
├── src/
│   └── index.js           ← Worker 入口：处理 /api/* 接口，其余请求转发给静态文件
├── public/
│   └── index.html          ← 前端页面（原样放着，不需要构建）
└── README.md
```

请求路径不变：`src/index.js` 是唯一的后端入口。路径是 `/api/posts` 或 `/api/like` 就由代码处理（内部用 SQL 操作 D1 数据库）；其余请求直接转交给 `public/` 目录下的静态文件。

## 部署步骤

### 第一步：创建 D1 数据库

**用 Dashboard（推荐，全程点点点）**

1. Cloudflare Dashboard → **Storage & Databases → D1 SQL Database** → **创建数据库**，随便起个名字，比如 `weiding-blog-db`。
2. 创建好之后，进入这个数据库 → **Console**（控制台），把 `schema.sql` 里的内容整段粘贴进去执行，建好 `posts` 和 `rate_limits` 两张表。
3. 记下数据库详情页里的 **Database ID**（一串 UUID），下一步要用。

**或者用 CLI**

```bash
npm install -g wrangler
wrangler login

# 创建数据库，会返回 database_id
wrangler d1 create weiding-blog-db

# 把表结构灌进去（注意要加 --remote，不然只会建在本地）
wrangler d1 execute weiding-blog-db --remote --file=./schema.sql
```

### 第二步：在 wrangler.toml 里启用 D1 绑定

把 `wrangler.toml` 末尾那几行的注释去掉，并填入上一步拿到的 `database_id`：

```toml
[[d1_databases]]
binding = "DB"
database_name = "weiding-blog-db"
database_id = "你的真实-database-id"
```

### 第三步：部署

**方式 A：Git 集成（推荐）**

1. 把整个文件夹（包含改好的 `wrangler.toml`）push 到 GitHub / GitLab 仓库。
2. Cloudflare Dashboard → **Workers & Pages**（或新版叫法 **Compute**）→ **创建** → 连接到这个仓库。
3. 构建命令、输出目录全部留空，直接部署即可——D1 绑定已经写在 `wrangler.toml` 里了，不需要再去 Dashboard 手动配置。

**方式 B：本地 CLI**

```bash
wrangler deploy
```

之后每次改完代码，重新执行 `wrangler deploy`（或 push 到 Git 触发自动部署）即可更新线上版本。

### 验证

部署成功后访问你的 `*.workers.dev` 域名（或绑定的自定义域名），发布一条内容，换个设备/浏览器打开同一个地址，应该能看到刚才发布的内容——说明大家共享同一个 D1 数据库了。

## 为什么换成 D1，和 KV 比有什么不同

| | KV | D1 |
|---|---|---|
| 数据模型 | 键值对 | 真正的关系型 SQL 表 |
| 排序/分页 | 需要手工设计 key 前缀来模拟排序 | 原生 `ORDER BY`、`WHERE`，更直观 |
| 一致性 | 最终一致（全球缓存，偶尔会有延迟） | 强一致（单一数据库实例） |
| 适合场景 | 简单缓存、配置、海量低频读写 | 有结构的业务数据，比如这种博客/评论场景 |
| 后续扩展 | 加字段、加查询条件比较别扭 | 加一列、加个表、写个 JOIN 都很自然 |

如果未来想加评论功能，只需要再加一张 `comments` 表（`post_id` 外键关联 `posts.id`），用一条 `SELECT ... WHERE post_id = ?` 就能查出某篇内容下的所有评论——这是 D1 比 KV 更适合长期迭代的地方。

## 关于内容安全

这是一个完全开放、无需登录的留言墙，意味着：

- 当前版本只做了最基础的防护：
  - 标题/正文长度限制（标题 ≤60 字，正文 ≤3000 字）
  - 隐藏的"蜜罐"字段，拦截掉大部分简单的自动化垃圾提交
  - 按 IP 限制发布频率（15 秒一次，存在 `rate_limits` 表里）
- **没有内容审核、没有删除接口、没有敏感词过滤**。如果是公开运营，强烈建议后续补充：
  - 一个简单的管理后台，或者直接在 D1 的 Dashboard Console 里手动执行 `DELETE FROM posts WHERE id = '...'` 删除不当内容
  - 接入 Cloudflare Turnstile 做人机验证，进一步防刷
  - 视情况加入敏感词过滤或人工审核队列

## 常用排查命令

```bash
# 直接在远程 D1 数据库里跑查询，比如看看一共有多少条内容
wrangler d1 execute weiding-blog-db --remote --command="SELECT COUNT(*) FROM posts"

# 看最新 10 条
wrangler d1 execute weiding-blog-db --remote --command="SELECT author, title, created_at FROM posts ORDER BY created_at DESC LIMIT 10"
```
