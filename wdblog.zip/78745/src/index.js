// src/index.js
// Cloudflare Worker 入口：先处理 /api/* 接口，其余请求交给静态资源（public/ 目录）。
// 数据存储使用 D1（SQL 数据库），需要在 wrangler.toml 里绑定一个 D1 database，变量名必须是 DB。

function jsonResponse(data, status) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

function jsonError(message, status) {
  return jsonResponse({ error: message }, status || 400);
}

function isValidLen(str, min, max) {
  return typeof str === "string" && str.length >= min && str.length <= max;
}

// ---------- GET /api/posts?limit=15&cursor=<createdAt> ----------
async function handleGetPosts(request, env) {
  if (!env.DB) {
    return jsonError("服务端未绑定 D1 数据库（DB），请检查 wrangler.toml 里的 d1_databases 配置。", 500);
  }

  const url = new URL(request.url);
  const limit = Math.min(Math.max(parseInt(url.searchParams.get("limit") || "15", 10) || 15, 1), 50);
  const cursor = url.searchParams.get("cursor");

  let stmt;
  if (cursor) {
    stmt = env.DB.prepare(
      "SELECT id, author, title, content, likes, created_at AS createdAt FROM posts WHERE created_at < ? ORDER BY created_at DESC LIMIT ?"
    ).bind(parseInt(cursor, 10), limit);
  } else {
    stmt = env.DB.prepare(
      "SELECT id, author, title, content, likes, created_at AS createdAt FROM posts ORDER BY created_at DESC LIMIT ?"
    ).bind(limit);
  }

  const { results } = await stmt.all();
  const nextCursor = results.length === limit ? results[results.length - 1].createdAt : null;

  return jsonResponse({ posts: results, cursor: nextCursor });
}

// ---------- POST /api/posts ----------
async function handleCreatePost(request, env) {
  if (!env.DB) {
    return jsonError("服务端未绑定 D1 数据库（DB），请检查 wrangler.toml 里的 d1_databases 配置。", 500);
  }

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return jsonError("请求格式错误", 400);
  }

  // honeypot anti-spam：真实用户永远不会填这个隐藏字段
  if (body.website) {
    return jsonError("提交被拦截", 400);
  }

  const author = (body.author || "").toString().trim().slice(0, 24) || "匿名旅人";
  const title = (body.title || "").toString().trim();
  const content = (body.content || "").toString().trim();

  if (!isValidLen(title, 1, 60)) return jsonError("标题需在 1-60 字之间", 400);
  if (!isValidLen(content, 1, 3000)) return jsonError("正文需在 1-3000 字之间", 400);

  // 简单的按 IP 限流，15 秒一次（存在 rate_limits 表里）
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  const now = Date.now();
  const rl = await env.DB.prepare("SELECT last_post FROM rate_limits WHERE ip = ?").bind(ip).first();
  if (rl && now - rl.last_post < 15000) {
    return jsonError("发布太频繁，请等几秒再试", 429);
  }
  await env.DB.prepare(
    "INSERT INTO rate_limits (ip, last_post) VALUES (?, ?) ON CONFLICT(ip) DO UPDATE SET last_post = excluded.last_post"
  ).bind(ip, now).run();

  const id = crypto.randomUUID();

  await env.DB.prepare(
    "INSERT INTO posts (id, author, title, content, likes, created_at) VALUES (?, ?, ?, ?, 0, ?)"
  ).bind(id, author, title, content, now).run();

  return jsonResponse({ post: { id, author, title, content, likes: 0, createdAt: now } }, 201);
}

// ---------- POST /api/like ----------
async function handleLike(request, env) {
  if (!env.DB) {
    return jsonError("服务端未绑定 D1 数据库（DB），请检查 wrangler.toml 里的 d1_databases 配置。", 500);
  }

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return jsonError("请求格式错误", 400);
  }

  const id = (body.id || "").toString();
  if (!id) {
    return jsonError("缺少内容 ID", 400);
  }

  const existing = await env.DB.prepare("SELECT likes FROM posts WHERE id = ?").bind(id).first();
  if (!existing) {
    return jsonError("内容不存在或已被删除", 404);
  }

  await env.DB.prepare("UPDATE posts SET likes = likes + 1 WHERE id = ?").bind(id).run();

  return jsonResponse({ likes: existing.likes + 1 });
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname === "/api/posts") {
      if (request.method === "GET") return handleGetPosts(request, env);
      if (request.method === "POST") return handleCreatePost(request, env);
      return jsonError("方法不允许", 405);
    }

    if (url.pathname === "/api/like") {
      if (request.method === "POST") return handleLike(request, env);
      return jsonError("方法不允许", 405);
    }

    // 非 API 请求：交给静态资源（public/ 目录下的 index.html 等文件）
    return env.ASSETS.fetch(request);
  },
};

